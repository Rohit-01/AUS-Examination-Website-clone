var li_items = document.querySelectorAll(".sidebar ul li");
var hamburger = document.querySelector(".hamburger");
var wrapper = document.querySelector(".wrapper");

// li_items.forEach((li_items)=>{
//     li_items.addEventListener("mouseenter",()=>{
//      li_items.closest(".wrapper").classList.remove("hover_collapse");
//     })
// })

// li_items.forEach((li_items)=>{
//     li_items.addEventListener("mouseleave",()=>{
//      li_items.closest(".wrapper").classList.add("hover_collapse");
//     })
// })



hamburger.addEventListener("click",()=>{
    hamburger.closest(".wrapper").classList.toggle("click_collapse")
    hamburger.closest(".wrapper").classList.toggle("hover_collapse");
})