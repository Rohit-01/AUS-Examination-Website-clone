<html>

    <head>
        <title>Registration Database </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <style>
            *
            {
                margin: 0;
                padding: 0;
                /* box-sizing: border-box; */
            }
            body{
                background-image : url("images/aus2.jpg");
                font-family: sans-serif;
                background-size: cover;
                backdrop-filter: blur(10px);
                background-position: center;
            }
            .heading{
                /* margin:20px auto 30px auto; */
                padding-top: 40px;
                text-align: center;
                color: #033364;
                font-size: 3rem;
            }
          
            .mid_container{
             
                margin-top:60px;
                padding-bottom:20%;
            }

         
            .tab{
                border-collapse: collapse;
                margin:30px auto 30px auto;
                font-size : 0.9rem;
                min-width: 400px;
                background-color: #fff;
            }

            .tab thead tr{
                background-color:#033364;
                color:#fff;
                text-align:left;
                /* font-weight:bold; */
            }

            .tab th,td{
                padding: 12px 15px

            }

            .tab tbody tr{
                border-bottom: 1px solid #dddddd;
            }
            
            /* .tab tbody tr:last-of-type{
                border-bottom: 2px solid #033364;
            } */

            i{
                padding-left:15px;
            }

            .banner{
                background-color: #033364;
                height: 80px;
            }
            
            img{
                height: 80px;
                margin-left: 50px;
            }
            .wr{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                margin-top:25px;
                position:absolute;
                color: #fff;
            }

        </style>
    
    </head>
    <body>
 
                    <?php
                            error_reporting(0); 
                          $p_email = $_POST["email"];
                          $p_password = $_POST["pass"];
        
                          $con= mysql_connect("localhost","root","");
                            if(!$con)
                            {
                                die("Cannot connect". mysql_error());
                            }
                           

                            $db_selected = mysql_select_db("studentdb",$con);

                            if(!$db_selected)
                            {
                                die("Cannot use student db : ". mysql_error());
                            }
                            
                            $qt = mysql_query("select * from admin where Email ='$p_email' and Password = '$p_password' ");

                            $row = mysql_fetch_array($qt);
                        
                            if($row['Email'] == $p_email && $row['Password']== $p_password)
                            {   
                                ?>
                                <script>
                                    alert("Loged In Successfully ");
                                </script>
                                <div class="banner">
                                <p>
                                    <img src="images/au-logo.jpg">
                                    <span class = "wr">Registration List</span>
                                </p>
                                </div>
                                <div class="top_container">
                                <h1 class="heading">Student List</h1>
                                
                                <div class="mid_container">
                                
                                <?php
                                $result = mysql_query("SELECT * FROM register");

                                echo  "<table class='tab'>";
                                echo "<thead>";
                                echo "<tr>";
                                    echo "<th>";
                                        echo "Registration ID";
                                    echo "</th>";
    
                                    echo"<th>";
                                        echo "Username";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Roll No.";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Date of Birth";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Email";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Gender";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Password";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Phone No.";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Add/Edit";
                                    echo "</th>";
                                    echo"<th>";
                                        echo "Delete";
                                    echo "</th>";
                                echo "</tr>";
                                echo "</thead>";
    
                                
                                    while($row = mysql_fetch_array($result))
                                    {
                                       echo "<tbody>"; 
    
                                        echo "<tr>";
    
                                        echo "<td>";
                                            echo $row[0];
                                        echo "</td>";
    
                                        echo "<td>";
                                            echo $row[1];
                                        echo "</td>";
    
                                        echo "<td>";
                                            echo $row[2];
                                        echo "</td>";
    
                                        echo "<td>";
                                            echo $row[3];
                                        echo "</td>";
    
                                        echo "<td>";
                                            echo $row[4];
                                        echo "</td>";
    
                                        echo "<td>";
                                            echo $row[5];
                                        echo "</td>";
    
                                        echo "<td>";
                                            echo $row[6];
                                        echo "</td>";
    
                                        echo "<td>";
                                            echo $row[7];
                                        echo "</td>";
                                        
                                        ?>

                                        <!-- // echo "<td>";
                                        //     echo "<a href='update.php? id = $row[0] & un = $row[Username] & rn = $row[Rollno] & db= $row[DOB] & em=$row[Email] & gn=$row[Gender] & pn=$row[PhoneNo] '>";
                                        //     echo "<i class='fas fa-user-edit'> </i>";
                                        //     echo "</a>";
                                        // echo "</td>";
    
                                        // echo "<td>";
                                        //     echo "<a href='delete.php? ids = $row[0]'>";
                                        //     echo "<i class='far fa-trash-alt'></i>";
                                        //     echo "</a>";
                                        // echo "</td>"; -->
    
                                        <td>
                                            <a href="update.php? id=<?php echo $row[0] ?> & un=<?php echo $row[1] ?>  & rn=<?php echo $row[2] ?>
                                            & db =<?php echo $row[3] ?>  & em=<?php echo $row[4] ?>  & ge=<?php echo $row[5] ?> & ph=<?php echo $row[7] ?> & ps=<?php echo $row[6] ?> ">
                                            <i class='fas fa-user-edit'> </i>
                                            </a> 
                                        </td>
                                     
                                        <td>
                                            <a href="delete.php? ids=<?php echo $row[0] ?>">
                                            <i class='far fa-trash-alt'></i>
                                            </a>
                                        </td>
                                        <?php
                                        echo "</tr>";
                                        
                                        echo "</tbody>";
                                    }
                                echo "</table>";
                                mysql_free_result("$result");
                                
                            }
                            else{
                                ?>
                                    <script>
                                        alert("Incorrect Password OR eamil");
                                    </script>
                                <?php
                            }
                            ?>        
                
                            </div>
                            </div>  
                    
   
   </body>
</html>
