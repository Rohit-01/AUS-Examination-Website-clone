<html>
    <head>
    <title>Welcome to student page</title>
        <meta charset="utf-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="data.css">
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Baloo+Paaji+2:wght@600&display=swap" rel="stylesheet">
    </head>
    <body>

                            <?php
                            error_reporting(0);
                            $p_regnumber = $_POST["s_reg"];
                            $p_pass = $_POST["s_pass"];
                            $con= mysql_connect("localhost","root","");

                            if(!$con)
                            {
                                die("Connection Unsuccessful : ".mysql_error());
                            }

                            $db_selected = mysql_select_db("studentdb",$con);

                            if(!$db_selected)
                            {
                                die("Cannot use studentdb : ".mysql_error());
                            }

                            $qr = mysql_query("select * from register where RegistrationID = '$p_regnumber' and Password = '$p_pass' ");

                            $row = mysql_fetch_array($qr);
                            if($row['RegistrationID'] == $p_regnumber && $row['Password']==$p_pass )
                            {   


                            ?>


                            <div class="wrapper hover_collapse">
                                <div class="top_navbar">
                                    <div class="logo">
                                        <img src="images/au-logo.jpg" alt="Assam uniersity">
                            
                                    </div>
                                    
                                    <div class="menu">
                                        <div class="hamburger">
                                            <i class="fas fa-bars"></i>
                                        </div>
                                    </div>
                                </div>
                    
                                <div class="sidebar">
                                    <div class="sidebar_inner">
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    <span class="icon"><i class="fas fa-house-user"></i></span>
                                                    <span class="text">Dashboard</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="icon"><i class="far fa-user"></i></span>
                                                    <span class="text">My Account</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="icon"><i class="fas fa-medal"></i></span>
                                                    <span class="text">My Qualification</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="icon"><i class="fas fa-edit"></i></span>
                                                    <span class="text">Registration</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="icon"><i class="fas fa-layer-group"></i></span>
                                                    <span class="text">My Academic</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="icon"><i class="fas fa-graduation-cap"></i></span>
                                                    <span class="text">Examination</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span class="icon"><i class="far fa-envelope"></i></span>
                                                    <span class="text">My Application</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="studenlogin.php">
                                                    <span class="icon"><i class="fas fa-power-off"></i></span>
                                                    <span class="text">Logout</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="main_container">
                                    <div class="container">
                                        <img src="images/allstudent2.png" alt="Profile picture" class="pro_pic">
                                            <p class="user">
                                                <?php
                                                    echo "<span class='msg'>";
                                                    echo "Login succesfull !!! <br>Welcome ".$row['Username'];
                                                    echo "</span>";
                                                ?>
                                            </p>
                                    </div>
                                </div>
                            </div>
                            <script src="scripts.js"></script>
                            <?php
                            }   
                                    else{
                                        ?>
                                        
                                        <script>
                                            alert("Incorrect password or Id")
                                        </script>
                                    <?php
                                    }
                            ?>
                   
                    <!-- <p>Reg No. 20180015596</p>
                    <p>BACHELOR OF TECHNOLOGY (2018-2019)</p> -->
           
    </body>
</html>