<html>

<head>
<title>Registration Database </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <style>
            *
            {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body{
                /* background-image : url("aus2.jpg"); */
                font-family: sans-serif;
                background-size: cover;
                height:100%;
                background-color:#F2F4F6;
                backdrop-filter: blur(10px);
                background-position: center;
            }


            i{
                padding-left:15px;
            }

            .banner{
                background-color: #033364;
                height: 80px;
            }
            
            img{
                height: 80px;
                margin-left: 50px;
            }
            .wr{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                margin-top:25px;
                position:absolute;
                color: #fff;
            }

            p.mid{
                font-size :2rem;
                color:#AF0404;
                /* background-color:#fff; */
                margin-top:190px;
                text-align:center;
                font-weight: bold;
            }

            button{
                padding:10px;
                border-radius: 6px;
                border: 1px solid grey;
                background-color:#AF0404;
                color:cyan;
            }
            .sub-header{
                font-size:1.2rem;
            }

            a{
                text-decoration: none;
                color:#fff;
                font-weight:bold;
            }
            a:hover{
                color:#000;
            }
            </style>
</head>

<body>
        <div class="banner">
            <p>
                <img src="images/au-logo.jpg">
                <!-- <span class = "wr">Registration List</span> -->
            </p>

        </div>



        <?php 

        $con= mysql_connect("localhost","root","");
        if(!$con)
        {
        die("Cannot connect". mysql_error());
        }
                                
        $db_selected = mysql_select_db("studentdb",$con);
        if(!$db_selected)
        {
                die("Cannot use student db : ". mysql_error());
        }


        error_reporting(0);
        $id = $_GET['ids'];
        $qt = mysql_query("DELETE FROM register WHERE RegistrationID = $id ");

            if (!$qt) {
                die('Could not query:' . mysql_error());
            }
        ?>

        <div class="top_container">
            
            <p class="mid">
               Deleted Succesfully <i class="fas fa-check"></i>
               <br><br>
               <button class="sub-header"><a href="managestudent.php" target='n'>Go back </a></button>
            </p>
        </div>  
</body>
</html>