<html>

    <head>
        <title>Registration Database </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <style>
             *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            }

            body{
                font-family: sans-serif;
                background-image: url("aus2.jpg");
                backdrop-filter: blur(5px);
                background-size:cover;
                background-position: center;
                overflow-x: hidden;
            }

            /* div.main::before{
                backdrop-filter: blur(5px);
                width: 100%;
            } */

            div.main{
                width: 400px;
                /* background-color: orange; */
    
                margin:100px auto 0px auto;
            }
            
            h2{
                text-align: center;
                padding: 20px;
                font-family: sans-serif;
                font-size: 22px;
                font-weight: 600;
            }

            div.register{
                background-color: rgb(106, 75, 75, 0.6);
                width: 100%;
                color: #fff;
                border:1px solid rgba(255,255,255,0.3);
                margin-top: 100px;
            }

            #register1{
                margin: 40px;
                font-size: 17px;
            }

            .data{
                width: 300px;
                border: 1px solid #fff;
                padding: 6px;
                box-shadow: inset 1px 1px 5px rgba(0,0,0,0.3);
            }

            #submit{
                font-size: 14px;
                font-family: sans-serif;
                background-color: #0072c6;
                border: none;
                border-radius: 2px;
                color:#fff;
                cursor: pointer;
                padding: 8px;
                width: 80px;
                height: 35px;
                margin-bottom: 20px;
            }

            a{
                text-decoration: none;
                list-style: none;
                color: #fff;
                font-weight: 600;
                font-size: 20px;
                padding: 0 5px auto 5px;
            }
            .banner{
                    background-color: #033364;
                    height: 80px;
            }
            img{
                    width: 80px;
                    margin-left: 20px;
                }
            .regis-sen{
                    font-size: 20px;
                    font-family: sans-serif;
                    font-weight: bold;
                    margin-left: 50px;
                    margin-top: 24px;
                    position:absolute;
                    color: #fff;
                }
                /* select.selector
                {   margin-top: 20px;
                    margin-left: 80%;
                    height:40px;
                    border: none;
                    font-size: 15px;
                    background-color: #033364;
                    color: white;
                }
                select.selector:hover{
                    background-color: white;
                    color: #033364;
                } */
        
        </style>
    
    </head>
    <body>
            
      
        <?php
                error_reporting(0);
                $t_id = $_POST["tcode"];
                $t_pass = $_POST["pass"];

                include_once("connection.php");

                 $result = mysql_query("select * from teacher where TeacherID = $t_id and Password = '$t_pass' ");
             
                 $row = mysql_fetch_array($result);

                 if($row['TeacherID'] == $t_id && $row['Password']==$t_pass )
                 {          
                  
                ?>

                <div class="banner">
                        
                        <p>
                            <img src="au-logo.jpg">
                            <span class="regis-sen"> Faculti Workspace</span>
                        </p>
                    
                </div>
                    <script>
                        alert("Login succesfull");
                        </script>
                    <div class="main">
                    <div class="register">
                    <h2>Marks Submission</h2>
                    <form id="register1" method="POST" action="faculti_in.php">
                        <label>Student Name</label>
                        <br>
                        <input type="text" name="sname" class="data" placeholder=" Student Name" required>
                        <br><br>
                        <label>Student Roll No.</label>
                        <br>
                        <input type="text" name="roll" class="data" placeholder=" Roll Number" required>
                        <br><br>
                        <label>Paper Code</label>
                        <br>
                        <input type="text" name="papercode" class="data" placeholder=" Paper Code " required>
                        <br><br>
                        <label> Paper Name </label>
                        <br>
                        <input type="text" name="papername" class="data" placeholder="Paper Name" required>
                        <br><br>
                        <label> Type </label>
                        <br>
                        <input type="text" name="type" class="data" placeholder=" Paper Type " required>
                        <br><br>
                        <label> Marks Obtained </label>
                        <br>
                        <input type="text" name="marks"  class="data" placeholder="Marks" required>
                        <br><br>
                        <input type="submit" value="Submit" name="submit" id="submit">
                        <br>
                        <a href="Registration.html">See database</a>
                    </form>
                    </div>
                    </div>
                    <?php
                 }
                 
                 ?>
                    <!-- // error_reporting(0); 
                    // $sname= $_POST["sname"];
                    // $roll = $_POST["roll"];
                    // $pcode = $_POST["papercode"];
                    // $pname = $_POST["papername"];
                    // $type = $_POST["type"];
                    // $marks = $_POST["marks"];

                    // $q2 = "insert into register values(' $sname', '$roll', '$pcode', '$pname', '$type', '$marks')";
                    // mysql_query($q1); -->
          
        <!-- <div class="top_container">
            
            <p class="mid">
               Marks Submitted succesfully <i class="fas fa-check-circle"></i>
               <br><br>
               <button class="sub-header"><a href="studenlogin.php" target='n'>See database </a></button>
            </p>
        </div>   -->


    </body>
</html>
