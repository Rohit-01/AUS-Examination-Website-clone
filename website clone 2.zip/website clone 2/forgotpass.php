<html>
    <head>

    <title>Reset Password </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>

        <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body{
            font-family: sans-serif;
            background-image: url("images/allstudent.jpg");
            backdrop-filter: blur(5px);
            background-size:cover;
            background-position: center;
            overflow-x: hidden;
        }

        /* div.main::before{
            backdrop-filter: blur(5px);
            width: 100%;
        } */

        div.main{
            width: 400px;
            /* background-color: orange; */
   
            margin:100px auto 0px auto;
        }
        
        h2{
            text-align: center;
            padding: 15px;
            margin-top:20px;
            font-family: sans-serif;
            font-size: 22px;
            font-weight: 600;
        }

        div.register{
            background-color: rgb(106, 75, 75, 0.6);
            width: 100%;
            color: #fff;
            border:1px solid rgba(255,255,255,0.3);
            margin-top: 100px;
        }

        #register1{
            margin: 20px 40px 40px 40px;
            font-size: 17px;
        }

        .data{
            width: 300px;
            border: 1px solid #fff;
            padding: 6px;
            margin-top:10px;
            box-shadow: inset 1px 1px 5px rgba(0,0,0,0.3);
        }

        #update{
            font-size: 14px;
            font-family: sans-serif;
            background-color: #0072c6;
            border: none;
            border-radius: 2px;
            color:#fff;
            cursor: pointer;
            padding: 8px;
            width: 80px;
            height: 35px;
            margin-bottom: 20px;
        }
        #update:hover{
            background-color: #3D84B8;
        }

        a{
            text-decoration: none;
            list-style: none;
            color: #fff;
            font-weight: 600;
            font-size: 15px;
            padding: 0 5px auto 5px;
        }
        a:hover
        {
            color: #000;
        }
        .banner{
                background-color: #033364;
                height: 80px;
        }
        img{
                width: 80px;
                margin-left: 20px;
            }
        .regis-sen{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                margin-top: 30px;
                color: #fff;
                position:absolute;

            }
            /* select.selector
            {   margin-top: 20px;
                margin-left: 80%;
                height:40px;
                border: none;
                font-size: 15px;
                background-color: #033364;
                color: white;
            }
            select.selector:hover{
                background-color: white;
                color: #033364;
            } */
        

    </style>
    </head>

    <body>


        
        <?php
                            error_reporting(0);
                            $p_regnumber = $_POST["s_reg"];
                            // $p_pass = $_POST["s_pass"];
                            $con= mysql_connect("localhost","root","");

                            if(!$con)
                            {
                                die("Connection Unsuccessful : ".mysql_error());
                            }

                            $db_selected = mysql_select_db("studentdb",$con);

                            if(!$db_selected)
                            {
                                die("Cannot use studentdb : ".mysql_error());
                            }

                            $qr = mysql_query("select * from register where RegistrationID = '$p_regnumber'  ");

                            $row = mysql_fetch_array($qr);
                            if($row['RegistrationID'] == $p_regnumber )
                            {   
                                ?>

                                <div class="banner">
            
                                <p>
                                    <img src="images/au-logo.jpg">
                                    <span class="regis-sen"> Reset Password </span>
                                </p>
                            
                            </div>
                            <div class="main">
                            <div class="register">
                            <h2> Reset Password </h2>
                            <form id="register1" method="POST" action="">
                            <?php

                            if(isset($_POST['update']))
                            {
                                if(isset($_POST['s_reg']))
                                {

                                
                                $p_registration = $_POST["s_reg"];

                                error_reporting(0); 
                                $pass = $_POST["pass"];

                                $qr = mysql_query("update register set Password = '$pass' where RegistrationID = $p_registration ");

                                $result = mysql_fetch_array($qr);
                                if($result){
                                ?>
                    
                                    <script>
                                        alert('Updated succesfully');
                                    </script>
                            
                                <?php
                                //  header("location: admin.php");
                                    }
                                else{
                                    ?>
                    
                                    <script>
                                        alert('Not Updated');
                                    </script>
                            
                                <?php
                                    }
                                }
                                else{
                                    echo " not set ";
                                }
                            }
                            ?>
                                
                                <label>New Password</label>
                                <br>
                                <input type="password" name="pass" class="data" placeholder="Enter New Password" required>
                                <br><br>

                                <input type="submit" value="Update" name="update" id="update">
                                <br>
                                <a href="studenlogin.php">Go To Login </a>
                            </form>

                                <?php

                            }
            else{

                echo " failed";
            }
    
        ?>
        
    


    </body>
</html>