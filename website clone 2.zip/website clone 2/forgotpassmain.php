<html>

<head>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="">
    <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+Paaji+2:wght@600&display=swap" rel="stylesheet">
    <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body{
            font-family: sans-serif;
            background-image: url("images/allstudent.jpg");
            backdrop-filter: blur(5px);
            background-size:cover;
            background-position: center;
            overflow-x: hidden;
        }

        /* div.main::before{
            backdrop-filter: blur(5px);
            width: 100%;
        } */

        div.main{
            width: 400px;
            /* background-color: orange; */
   
            margin:100px auto 0px auto;
        }
        
        h2{
            text-align: center;
            padding: 20px;
            font-family: sans-serif;
            font-size: 22px;
            font-weight: 600;
        }

        div.register{
            background-color: rgb(106, 75, 75, 0.6);
            width: 100%;
            color: #fff;
            border:1px solid rgba(255,255,255,0.3);
            margin-top: 100px;
        }

        #register1{
            margin: 40px;
            font-size: 17px;
        }

        .data{
            width: 300px;
            border: 1px solid #fff;
            padding: 6px;
            box-shadow: inset 1px 1px 5px rgba(0,0,0,0.3);
        }

        #submit{
            font-size: 14px;
            font-family: sans-serif;
            background-color: #0072c6;
            border: none;
            border-radius: 2px;
            color:#fff;
            cursor: pointer;
            padding: 8px;
            width: 80px;
            height: 35px;
            margin-bottom: 20px;
        }

        a{
            text-decoration: none;
            list-style: none;
            color: red;
            font-weight: 600;
            font-size: 15px;
            padding: 0 5px auto 5px;
        }
        .banner{
                background-color: #033364;
                height: 80px;
        }
        img{
                width: 80px;
                margin-left: 20px;
            }
        .regis-sen{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                color: #fff;
            }
            /* select.selector
            {   margin-top: 20px;
                margin-left: 80%;
                height:40px;
                border: none;
                font-size: 15px;
                background-color: #033364;
                color: white;
            }
            select.selector:hover{
                background-color: white;
                color: #033364;
            } */
        

    </style>
</head>
<body>
 
    <div class="banner">
        
        <p>
            <img src="images/au-logo.jpg">
            <span class="regis-sen"> Reset Password</span>
        </p>
       
    </div>

    <div class="main">
    <div class="register">
    <h2>Reset Password Form</h2>
    <form id="register1" method="POST" action="forgotpass.php">
        <label>Registration ID</label>
        <br><br>
        <input type="text" placeholder="Registration No." name="s_reg">
        <br>
        <!-- <input type="password" placeholder="Password" name="s_pass">
        <br> -->
        <input type="submit" value="Submit" name="submit" id="submit">
        <br>
         <a href="studenlogin.php">Already Registered? Go Back to Login</a>
    </form>
    </div>
    </div>
</body>
</html>