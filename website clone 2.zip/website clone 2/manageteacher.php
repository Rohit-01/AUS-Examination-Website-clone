<html>
    <head>
    <title>Welcome to Admin page</title>
        <meta charset="utf-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="teacherstyles.css">
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Baloo+Paaji+2:wght@600&display=swap" rel="stylesheet">

        <style>
            /* .add_btn{

                background-color:green;
            } */
        </style>
    </head>
    <body>

                         
                    <?php
                            error_reporting(0); 
                          $p_email = $_POST["email"];
                          $p_password = $_POST["pass"];
        
                          $con= mysql_connect("localhost","root","");
                            if(!$con)
                            {
                                die("Cannot connect". mysql_error());
                            }
                           

                            $db_selected = mysql_select_db("studentdb",$con);

                            if(!$db_selected)
                            {
                                die("Cannot use student db : ". mysql_error());
                            }
                            
                            $qt = mysql_query("select * from admin where Email ='$p_email' and Password = '$p_password' ");

                            $row = mysql_fetch_array($qt);
                        
                            if($row['Email'] == $p_email && $row['Password']== $p_password)
                            { 

                            ?>


                            <div class="wrapper hover_collapse">
                                <div class="top_navbar">
                                    <div class="logo">
                                        <img src="images/au-logo.jpg" alt="Assam uniersity">
                            
                                    </div>
                                    
                                    <div class="menu">
                                        <div class="hamburger">
                                            <i class="fas fa-bars"></i>
                                        </div>
                                    </div>
                                </div>
                    
                                <div class="sidebar">
                                    <div class="sidebar_inner">
                                        <ul>
                                            <li>
                                                <a href="managestudent.php">
                                                    <span class="icon"><i class="fas fa-house-user"></i></span>
                                                    <span class="text">Manage student</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="manageteacher.php">
                                                    <span class="icon"><i class="far fa-user"></i></span>
                                                    <span class="text">Manage teacher</span>
                                                </a>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>

                                <div class="main_container">
                                    <div class="container">

                                        <button class="add_btn"><a href="teachersignup.html" class="teach"> Add Teacher </a></button>


                                        <?php
                                             $result = mysql_query("SELECT * FROM teacher");

                                             echo  "<table class='tab'>";
                                             echo "<thead>";
                                             echo "<tr>";
                                                 echo "<th>";
                                                     echo "Falculty ID";
                                                 echo "</th>";
                 
                                                 echo"<th>";
                                                     echo "Faculty Name";
                                                 echo "</th>";

                                                 echo "<th>";
                                                     echo "Email";
                                                 echo "</th>";

                                                 echo"<th>";
                                                     echo "Phone No.";
                                                 echo "</th>";
                                                    
                                                 echo"<th>";
                                                     echo "Password";
                                                 echo "</th>";

                                                 echo"<th>";
                                                     echo "Add/Edit";
                                                 echo "</th>";
                                                 echo"<th>";
                                                     echo "Delete";
                                                 echo "</th>";
                                             echo "</tr>";
                                             echo "</thead>";
                 
                                             
                                                 while($row = mysql_fetch_array($result))
                                                 {
                                                    echo "<tbody>"; 
                 
                                                     echo "<tr>";
                 
                                                     echo "<td>";
                                                         echo $row[0];
                                                     echo "</td>";
                 
                                                     echo "<td>";
                                                         echo $row[1];
                                                     echo "</td>";
                 
                                                     echo "<td>";
                                                         echo $row[2];
                                                     echo "</td>";
                 
                                                     echo "<td>";
                                                         echo $row[3];
                                                     echo "</td>";
                 
                                                     echo "<td>";
                                                         echo $row[4];
                                                     echo "</td>";
                                                     
                                                     ?>
             
                                                     <!-- // echo "<td>";
                                                     //     echo "<a href='update.php? id = $row[0] & un = $row[Username] & rn = $row[Rollno] & db= $row[DOB] & em=$row[Email] & gn=$row[Gender] & pn=$row[PhoneNo] '>";
                                                     //     echo "<i class='fas fa-user-edit'> </i>";
                                                     //     echo "</a>";
                                                     // echo "</td>";
                 
                                                     // echo "<td>";
                                                     //     echo "<a href='delete.php? ids = $row[0]'>";
                                                     //     echo "<i class='far fa-trash-alt'></i>";
                                                     //     echo "</a>";
                                                     // echo "</td>"; -->
                 
                                                     <td>
                                                         <a href="teacherdataup.php? id=<?php echo $row[0] ?> & un=<?php echo $row[1] ?>  & em=<?php echo $row[2] ?>
                                                         & ph=<?php echo $row[3] ?>   & pas=<?php echo $row[4] ?> ">
                                                         <i class='fas fa-user-edit'> </i>
                                                         </a> 
                                                     </td>
                                                  
                                                     <td>
                                                         <a href="teacherdatadel.php? ids=<?php echo $row[0] ?>">
                                                         <i class='far fa-trash-alt'></i>
                                                         </a>
                                                     </td>

                                                     <?php
                                                     echo "</tr>";
                                                     
                                                     echo "</tbody>";
                                                 }
                                             echo "</table>";
                                             mysql_free_result("$result");
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <script src="admin.js"></script>
                            <?php
                            }   
                                    else{
                                        ?>
                                        
                                        <script>
                                            alert("Incorrect password or Id")
                                        </script>
                                    <?php
                                    }
                            ?>
                   
                    <!-- <p>Reg No. 20180015596</p>
                    <p>BACHELOR OF TECHNOLOGY (2018-2019)</p> -->
           
    </body>
</html>