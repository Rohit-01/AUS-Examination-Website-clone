<html>
    <body>

        <?php
            error_reporting(0); 

            $p_fname = $_POST["h_fname"];
            $p_lname = $_POST["h_lname"];
            $p_age = $_POST["h_age"];

            echo "Hi  " .$p_fname;
            
            echo "<br> Your full name is " .$p_fname. " " .$p_lname;

            echo "<br> Your age is <br>" .$p_age;

            $con = mysql_connect('localhost','root','');

            if(!$con)
            {
                die("Could not connect ".mysql_error());             
            }

            $db_selected = mysql_select_db("studentdb",$con);

            if(!$db_selected)
            {
                die("Cannot use studentdb : ".mysql_error());
                exit();
            }
           else{
               echo"<br> Hurreyy Its connected! ";
           }

           $ct = "create table if not exits person(m_fname varchar(40), m_lname varchar(40), m_age int)";
           mysql_query($ct);
           $sl= "insert into person values('$p_fname','$p_lname','$p_age')";
           mysql_query($sl);
           
           printf(" <br> <br> Your Data is successfully inserted! <br>");
        
        
            //  mysql_connect('localhost','root','');
            //  mysql_select_db("studentdb");
            //  $sql = "SELECT * FROM person";
            //  $result = mysql_query($sql);
            //  $num_rows = mysql_num_rows($result);

            //  echo $num_rows;


            // mysql_connect('localhost','root','');
            // mysql_select_db("studentdb");
            // $sql = "DELETE FROM person WHERE m_age > 20";
            // mysql_query($sql);
            // $affected_rows = mysql_affected_rows();

            // echo "Records deleted: " .$affected_rows;



            // mysql_connect('localhost','root','');
            // mysql_select_db("studentdb");
            $result = mysql_query("SELECT * FROM person");
            
            echo"<table border=1>";
            echo "<tr>";
                echo "<td>";
                    echo "FIRST NAME";
                echo "</td>";

                echo "<td>";
                    echo"LAST NAME";
                echo "</td>";
        
                echo "<td>";
                    echo"AGE";
                echo "</td>";
            echo "</tr>";


             while($row = mysql_fetch_array($result))
            {
                echo "<tr>";

                echo "<td>";
                     echo $row[0];
                echo "</td>";
                echo "<td>";
                     echo $row[1];
                echo "</td>";

                echo "<td>"; 
                    echo $row[2];
                 echo "</td>";
                echo"</tr>";
            }

            echo"</table border=1>";
        
            mysql_free_result($result);
        
        
        ?>

    </body>
</html>