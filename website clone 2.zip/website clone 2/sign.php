<html>

    <head>
        <title>Registration Database </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <style>
            *
            {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body{
                /* background-image : url("aus2.jpg"); */
                font-family: sans-serif;
                background-size: cover;
                height:100%;
                background-color:#DEEEEA;
                backdrop-filter: blur(10px);
                background-position: center;
            }


            i{
                padding-left:15px;
            }

            .banner{
                background-color: #033364;
                height: 80px;
            }
            
            img{
                height: 80px;
                margin-left: 50px;
            }
            .wr{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                margin-top:25px;
                position:absolute;
                color: #fff;
            }

            p.mid{
                font-size :2rem;
                color:#01937C;
                /* background-color:#fff; */
                margin-top:190px;
                text-align:center;
                font-weight: bold;
            }

            button{
                padding:10px;
                border-radius: 6px;
                border: 1px solid grey;
                background-color:#01937C;
                color:cyan;
            }
            .sub-header{
                font-size:1.2rem;
            }

            a{
                text-decoration: none;
                color:#fff;
                font-weight:bold;
            }
            a:hover{
                color:#393E46;
            }
        </style>
    
    </head>
    <body>
        <div class="banner">
            <p>
                <img src="images/au-logo.jpg">
                <span class = "wr">Registration List</span>
            </p>
        </div>

        <?php

                error_reporting(0); 
                $reg_id = $_POST["registration"];
                $user = $_POST["username"];
                $roll = $_POST["roll"];
                $dob = $_POST["dob"];
                $email = $_POST["email"];
                $gender = $_POST["gender"];
                $pass = $_POST["pass"];
                $phone = $_POST["phone"];

                $con = mysql_connect("localhost","root","");

                if(!$con)
                {
                    die("Cannot connect". mysql_error());
                }

                $db_selected = mysql_select_db("studentdb",$con);

                if(!$db_selected)
                {
                    die("Cannot use student db : ". mysql_error());
                }

                $q1 = "create table if not exits register (RegistrationID bigint, Username varchar(50), RollNo bigint, DOB varchar(20), Email varchar(50), Gender varchar(40), Password varchar(50), PhoneNo bigint)";
                mysql_query($q1);

                $q2 = "insert into register values('$reg_id', '$user', '$roll', '$dob', '$email', '$gender','$pass', '$phone')";
                mysql_query($q2);
        ?>
        
        <div class="top_container">
            
            <p class="mid">
               Registration Succesfull <i class="fas fa-check-circle"></i>
               <br><br>
               <button class="sub-header"><a href="studenlogin.php" target='n'>Go to Login </a></button>
            </p>
        </div>  


   
    </body>
</html>
