<html>

<body>
    <?php

        
        $con= mysql_connect("localhost","root","");
        if(!$con)
        {
            die("Cannot connect". mysql_error());
        }


        $db_selected = mysql_select_db("studentdb",$con);

        if(!$db_selected)
        {
            die("Cannot use student db : ". mysql_error());
        }

        error_reporting(0);
        $p_reg = $_POST['regis'];
        $p_user = $_POST['user'];

        $query = mysql_query("select * from register where RegistrationID = '$p_reg' and Username ='$p_user'")
                    or die("Failed to query database ".mysql_error());

        $row = mysql_fetch_array($query);

        if($row['RegistrationID']== $p_reg && $row['Username']== $p_user)
        {   
            include 'fmain.php';
           
        }
        else{
            ?>
            <script>
                alert("Student Verification Failed ");
            </script>

            <?php
        }
    
    ?>
</body>


</html>