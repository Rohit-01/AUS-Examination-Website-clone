<html>
    <head>
        <title> Student login </title>
        <meta charset="utf-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- <link rel="stylesheet" href="style.css"> -->
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="style.css">
        <style>
            *{
                box-sizing: border-box;
            }

            body{
                font-family: sans-serif;
                font-size: 16px;
                color: #fff;
                backdrop-filter: blur(10px);
            }
            #new{
                background-color: rgba(185, 204, 204, 0.5);
                margin: auto;
                margin-top: 14%;
                padding: 40px;
                border-radius: 5px;
                box-shadow: 0 0 10p;
                position: absolute;
                top: 0;
                bottom:0;
                left: 0;
                right: 0;
                width: 500px;
                height: 430px;
                
            }

            #new::before{
                background-image: url(images/aus2.jpg);
                width: 100%;
                height: 100%;
                background-size: cover;
                position: fixed;
               
            }

            .head-text{
                font-size: 32px;
                font-weight: 600;
                padding-bottom: 30px;
                text-align: left;
            }
            input{
                margin: 10px 0;
                border: none;
                padding: 10px;
                border-radius: 5px;
                width: 100%;
                font-size: 16px;
                font-family: sans-serif;
            }
            button{
                background-color: #00CED1;
                color:#fff;
                border:none;
                border-radius: 5px;
                cursor: pointer;
                width: 60px;
                height: 30px;
                font-size: 16px;
                margin: 20px 0;
            }
            button:hover{
                background-color: turquoise;
            }
            .au-logo{
                width:110px;
                margin:50px auto 20px 46%;
            }
            a.pass{
                font-size: 15px;
                
            }
        </style>
        
    </head>

    <body>  
        
        <img src="images/au-logo.jpg" class="au-logo">
        <form id="new" action="data1.php" method="POST">
            <div class="head-text">Login to your account</div>
            <input type="text" placeholder="Registration No." name="s_reg">
            <input type="password" placeholder="Password" name="s_pass">
            <button>Login</button>
            <br>
            <label><a href="#" class="pass">Forgot password?</a></label>
        </form>
     
    </body>
</html>