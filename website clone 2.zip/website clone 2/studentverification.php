<html>

    <head>
        <title>Registration Database </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <style>
            *
            {
                margin: 0;
                padding: 0;
                /* box-sizing: border-box; */
            }
            body{
                background-image : url("images/aus2.jpg");
                font-family: sans-serif;
                background-size: cover;
                backdrop-filter: blur(10px);
                background-position: center;
            }
            .heading{
                /* margin:20px auto 30px auto; */
                padding-top: 40px;
                text-align: center;
                color: #033364;
                font-size: 3rem;
            }
          
            .mid_container{
             
                margin-top:60px;
                padding-bottom:20%;
            }

         
            .tab{
                border-collapse: collapse;
                margin:30px auto 30px auto;
                font-size : 0.9rem;
                min-width: 400px;
                background-color: #fff;
            }

            .tab thead tr{
                background-color:#033364;
                color:#fff;
                text-align:left;
                /* font-weight:bold; */
            }

            .tab th,td{
                padding: 12px 15px

            }

            .tab tbody tr{
                border-bottom: 1px solid #dddddd;
            }
            
            /* .tab tbody tr:last-of-type{
                border-bottom: 2px solid #033364;
            } */

            i{
                padding-left:15px;
            }

            .banner{
                background-color: #033364;
                height: 80px;
            }
            
            img{
                height: 80px;
                margin-left: 50px;
            }
            .wr{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                margin-top:25px;
                position:absolute;
                color: #fff;
            }

        </style>
    
    </head>
    <body>
 
                    <?php
                            error_reporting(0); 
                          $reg = $_POST['regis'];
                          $user = $_POST["user"];
                          
        
                          $con = mysql_connect("localhost","root","");
                            if(!$con)
                            {
                                die("Cannot connect". mysql_error());
                            }
                           

                            $db_selected = mysql_select_db("studentdb",$con);

                            if(!$db_selected)
                            {
                                die("Cannot use student db : ". mysql_error());
                            }
                            
                            $qt = mysql_query("select * from register where RegistrationID ='$reg' and Username = '$user' ");
                            echo $qt;
                            $result = mysql_fetch_array($qt);
                        
                            if($result['RegistrationID'] == $reg && $result['Username'] == $user)
                            {   
                                include 'facultiwork.php';
                                echo "Entered";
                            }
                            else{
                                echo " not displayed";
                            }
                        ?>
                    </body>
                </html>