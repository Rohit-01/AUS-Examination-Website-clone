<html>
    <head>
    <title>Welcome to Faculti Page</title>
        <meta charset="utf-8">
    
        <link href="https://fonts.googleapis.com/css2?family=Baloo+Paaji+2:wght@600&display=swap" rel="stylesheet">

        <style>
             *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            }

            body{
                font-family: sans-serif;
                background-image: url("images/aus2.jpg");
                backdrop-filter: blur(5px);
                background-size:cover;
                background-position: center;
                overflow-x: hidden;
            }

            /* div.main::before{
                backdrop-filter: blur(5px);
                width: 100%;
            } */

            div.main{
                width: 400px;
                /* background-color: orange; */
    
                margin:100px auto 0px auto;
            }
            
            h2{
                text-align: center;
                padding: 20px;
                font-family: sans-serif;
                font-size: 22px;
                font-weight: 600;
            }

            div.register{
                background-color: rgb(106, 75, 75, 0.6);
                width: 100%;
                color: #fff;
                border:1px solid rgba(255,255,255,0.3);
                margin-top: 100px;
            }

            #register1{
                margin: 40px;
                font-size: 17px;
            }

            .data{
                width: 300px;
                border: 1px solid #fff;
                padding: 6px;
                box-shadow: inset 1px 1px 5px rgba(0,0,0,0.3);
            }

            #update{
                font-size: 14px;
                font-family: sans-serif;
                background-color: #0072c6;
                border: none;
                border-radius: 2px;
                color:#fff;
                cursor: pointer;
                padding: 8px;
                width: 80px;
                height: 35px;
                margin-bottom: 20px;
            }

            a{
                text-decoration: none;
                list-style: none;
                color: #fff;
                font-weight: 600;
                font-size: 20px;
                padding: 0 5px auto 5px;
            }

            a:hover{
                color:#01937C;
            }

            .banner{
                    background-color: #033364;
                    height: 80px;
            }
            img{
                    width: 80px;
                    margin-left: 20px;
                }
            .regis-sen{
                    font-size: 20px;
                    font-family: sans-serif;
                    font-weight: bold;
                    margin-left: 50px;
                    margin-top: 24px;
                    position:absolute;
                    color: #fff;
                }
                /* select.selector
                {   margin-top: 20px;
                    margin-left: 80%;
                    height:40px;
                    border: none;
                    font-size: 15px;
                    background-color: #033364;
                    color: white;
                }
                select.selector:hover{
                    background-color: white;
                    color: #033364;
                } */
        
        </style>
    


    </head>

    <body>
                <div class="banner">
                        
                        <p>
                            <img src="images/au-logo.jpg">
                            <span class="regis-sen"> Faculty Workspace</span>
                        </p>
                    
                </div>


                    <script>
                        alert("Login succesfull");
                        </script>
                    <div class="main">
                    <div class="register">
                    <h2>Manage Faculty Data </h2>
                    <form id="register1" method="POST" action="">
                        
                    
                        <?php

                        error_reporting(0);
                        $con = mysql_connect("localhost","root","");
                        if(!$con)
                        {
                            die(mysql_error());
                        }

                        $db_selected =  mysql_select_db("studentdb",$con);

                        if(!$db_selected)
                        {
                            die( mysql_error());
                        }



                        $id= $_GET['id'];
                        $un= $_GET['un'];
                        $em= $_GET['em'];
                        $ph= $_GET['ph'];
                        $pas= $_GET['pas'];
                        


                        // $squery = " select * from register where RegistrationID = '$id' ";
                        // $query = mysql_query( $squery);

                        // $row = mysql_fetch_array($query);

                        if(isset($_POST['update']))
                        {

                        $rn= $_GET['rn'];

                        error_reporting(0); 
                        $facid = $_POST["facid"];
                        $fname= $_POST["fname"];
                        $email = $_POST["email"];
                        $phone= $_POST["phone"];
                        $password = $_POST["password"];
                      

                        $updatequery = "update teacher set TeacherID = $facid , Name = '$fname', Email = '$email' , phone = '$phone', Password = '$password' where TeacherID =$id";
                        $query = mysql_query($updatequery);
                     
                        if($query){
                            ?>

                            <script>
                                alert('Updated succesfully');
                            </script>

                        <?php
                        //  header("location: admin.php");
                        }
                        else{
                            ?>

                            <script>
                                alert('Not Updated');
                            </script>

                        <?php
                        }

                        }
                        ?>

                        <label>Faculty ID</label>
                        <br>
                        <input type="text" name="facid" value="<?php echo $id; ?>" class="data" placeholder="Enter Faculty ID" required>
                        <br><br>
                        <label>Faculty Name</label>
                        <br>
                        <input type="text" name="fname" value="<?php echo $un; ?>" class="data" placeholder=" Enter Faculty Name" required>
                        <br><br>
                        <label>Email</label>
                        <br>
                        <input type="email" name="email" value="<?php echo $em; ?>" class="data" placeholder="  Enter Email " required>
                        <br><br>
                        <label>Phone No.</label>
                        <br>
                        <input type="text" name="phone" value="<?php echo $ph ?>" class="data" placeholder="Enter  Phone No." required>
                        <br><br>
                        <label> Passwrord </label>
                        <br>
                        <input type="password" name="password" value="<?php echo $pas; ?>" class="data" placeholder=" Enter Password " required>
                        <br><br>
          
                        <input type="submit" value="Update" name="update" id="update">
                        <br>
                          
                        <a href="manageteacher.php"> Go Back to Dashboard </a>
                        
                    </form>
                    </div>
                    </div>
                
           
    </body>
</html>