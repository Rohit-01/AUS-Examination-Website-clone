<html>

    <head>
        <title>Registration Database </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>
        <style>
            *
            {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body{
                /* background-image : url("aus2.jpg"); */
                font-family: sans-serif;
                background-size: cover;
                height:100%;
                background-color:#DEEEEA;
                backdrop-filter: blur(10px);
                background-position: center;
            }


            i{
                padding-left:15px;
            }

            .banner{
                background-color: #033364;
                height: 80px;
            }
            
            img{
                height: 80px;
                margin-left: 50px;
            }
            .wr{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                margin-top:25px;
                position:absolute;
                color: #fff;
            }

            p.mid{
                font-size :2rem;
                color:#01937C;
                /* background-color:#fff; */
                margin-top:190px;
                text-align:center;
                font-weight: bold;
            }

            button{
                padding:10px;
                border-radius: 6px;
                border: 1px solid grey;
                background-color:#01937C;
                color:cyan;
            }
            .sub-header{
                font-size:1.2rem;
            }

            a{
                text-decoration: none;
                color:#fff;
                font-weight:bold;
            }
            a:hover{
                color:#393E46;
            }
        </style>
    
    </head>
    <body>
        <div class="banner">
            <p>
                <img src="images/au-logo.jpg">
                <span class = "wr">Admin Workspace</span>
            </p>
        </div>

        <?php

                 error_reporting(0); 
                 $facid = $_POST["facid"];
                 $fname= $_POST["fname"];
                 $email = $_POST["email"];
                 $phone= $_POST["phone"];
                 $password = $_POST["password"];

                $con = mysql_connect("localhost","root","");

                if(!$con)
                {
                    die("Cannot connect". mysql_error());
                }

                $db_selected = mysql_select_db("studentdb",$con);

                if(!$db_selected)
                {
                    die("Cannot use student db : ". mysql_error());
                }
                else{
                    echo "connected";
                }

                $q1 = "create table if not exits teacher (TeacherID bigint, Name varchar(50), Email varchar(50), phone bigint, Password varchar(50))";
                mysql_query($q1);

                $q2 = "insert into teacher values($facid, '$fname', '$email', $phone, '$email', '$password')";
                mysql_query($q2);
        ?>
        
        <div class="top_container">
            
            <p class="mid">
               Added Succesfully <i class="fas fa-check-circle"></i>
               <br><br>
               <button class="sub-header"><a href="manageteacher.php" target='n'>Go back to Dashboard </a></button>
            </p>
        </div>  


   
    </body>
</html>
