
<html>

<head>
        <title>Registration Database </title>
        <script src="https://kit.fontawesome.com/babd869b62.js" crossorigin="anonymous"></script>

        <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body{
            font-family: sans-serif;
            background-image: url("images/allstudent.jpg");
            backdrop-filter: blur(5px);
            background-size:cover;
            background-position: center;
            overflow-x: hidden;
        }

        /* div.main::before{
            backdrop-filter: blur(5px);
            width: 100%;
        } */

        div.main{
            width: 400px;
            /* background-color: orange; */
   
            margin:100px auto 0px auto;
        }
        
        h2{
            text-align: center;
            padding: 20px;
            font-family: sans-serif;
            font-size: 22px;
            font-weight: 600;
        }

        div.register{
            background-color: rgb(106, 75, 75, 0.6);
            width: 100%;
            color: #fff;
            border:1px solid rgba(255,255,255,0.3);
            margin-top: 100px;
        }

        #register1{
            margin: 40px;
            font-size: 17px;
        }

        .data{
            width: 300px;
            border: 1px solid #fff;
            padding: 6px;
            box-shadow: inset 1px 1px 5px rgba(0,0,0,0.3);
        }

        #update{
            font-size: 14px;
            font-family: sans-serif;
            background-color: #0072c6;
            border: none;
            border-radius: 2px;
            color:#fff;
            cursor: pointer;
            padding: 8px;
            width: 80px;
            height: 35px;
            margin-bottom: 20px;
        }

        a{
            text-decoration: none;
            list-style: none;
            color: red;
            font-weight: 600;
            font-size: 15px;
            padding: 0 5px auto 5px;
        }
        .banner{
                background-color: #033364;
                height: 80px;
        }
        img{
                width: 80px;
                margin-left: 20px;
            }
        .regis-sen{
                font-size: 20px;
                font-family: sans-serif;
                font-weight: bold;
                margin-left: 50px;
                margin-top: 30px;
                color: #fff;
                position:absolute;

            }
            /* select.selector
            {   margin-top: 20px;
                margin-left: 80%;
                height:40px;
                border: none;
                font-size: 15px;
                background-color: #033364;
                color: white;
            }
            select.selector:hover{
                background-color: white;
                color: #033364;
            } */
        

    </style>
</head>
<body>

    <div class="banner">
        
        <p>
            <img src="images/au-logo.jpg">
            <span class="regis-sen"> New Registration</span>
        </p>
       
    </div>

    <div class="main">
    <div class="register">
    <h2>New Candidate - Registration</h2>
    <form id="register1" method="POST" action="">
        

        <?php

            error_reporting(0);
            $con = mysql_connect("localhost","root","");
            if(!$con)
            {
                die(mysql_error());
            }

            $db_selected =  mysql_select_db("studentdb",$con);

            if(!$db_selected)
            {
                die( mysql_error());
            }
         

            
            $id= $_GET['id'];
            $un= $_GET['un'];
            $rn= $_GET['rn'];
            $db= $_GET['db'];
            $em= $_GET['em'];
            $ge= $_GET['ge'];
            $ph= $_GET['ph'];
            
           
            // $squery = " select * from register where RegistrationID = '$id' ";
            // $query = mysql_query( $squery);
    
            // $row = mysql_fetch_array($query);

            if(isset($_POST['update']))
            {

            $id= $_GET['id'];

            error_reporting(0); 
            $reg_id = $_POST["registration"];
            $user = $_POST["username"];
            $roll = $_POST["roll"];
            // $dob = $_POST["dob"];
            $email = $_POST["email"];
            // $gender = $_POST["gender"];
            $phone = $_POST["phone"];


            $updatequery = "update register set RegistrationID = $reg_id , Username = '$user', Rollno = $roll , Email= '$email', PhoneNo = $phone where RegistrationID = $id";
            $query = mysql_query($updatequery);
            // $q1 = "create table if not exits register (RegistrationID bigint, Username varchar(50), RollNo bigint, DOB varchar(20), Email varchar(50), Gender varchar(40), Password varchar(50), PhoneNo bigint)";
            // mysql_query($q1);

            // $q2 = "insert into register values('$reg_id', '$user', '$roll', '$dob', '$email', '$gender','$pass', '$phone')";
            // mysql_query($q2);
            if($query){
                ?>

                <script>
                     alert('Updated succesfully');
                  </script>
          
             <?php
            //  header("location: admin.php");
            }
            else{
                ?>

                <script>
                     alert('Not Updated');
                  </script>
          
             <?php
            }
         
            }
        ?>

         
        <label>Registration ID</label>
        <br>
        <input type="text" name="registration" value="<?php echo $id; ?>" class="data" placeholder="Enter Your Registration ID" required>
        <br><br>
        <label>Username </label>
        <br>
        <input type="text" name="username" value="<?php echo $un ?>" class="data" placeholder="Enter Your Name" required>
        <br><br>
        <label>Roll No.</label>
        <br>
        <input type="text" name="roll" value="<?php echo $rn;  ?>" class="data" placeholder="Enter Your Roll Number" required>
        <br><br>
        <!-- <label> Date of Birth </label>
        <br>
        <input type="date" name="dob" value="<?php echo $db; ?>" class="data" required>
        <br><br> -->
        <label> Email </label>
        <br>
        <input type="text" name="email" value="<?php echo $em; ?>" class="data" placeholder="Enter Your Email" required>
        <br><br>
        
        <label>Phone No.</label>
        <br>
        <input type="text" name="phone" value="<?php echo $ph ?>" class="data" placeholder="Enter Your Phone No." required>
        <br><br>
        <input type="submit" value="Update" name="update" id="update">
        <br>
         <a href="managestudent.php">Go Back to Dashboard</a>
    </form>
    </div>
    </div>
</body>
</html>